import numpy as np
import string
import re
from keras.models import Sequential
from keras.layers import Activation
from keras.layers import Lambda
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import LSTM
from keras.utils import np_utils
def load_txt(f):
    f = open(f, 'r')
    txt = f.read()
    txt = txt.translate(str.maketrans('','',string.punctuation))
    txt = txt.translate(str.maketrans('','','1234567890'))
    f.close()
    return txt

'''
We are predicting the next character from only 40 characters of
input text. Whitespace and newline characters are included
because the model needs to learn when the beginning of a 
new word/line is.
All characters are converted to lower-case.'''

file = load_txt('data/shakespeare.txt')
# cleaning
clean = re.findall(r'\S+|\n',file)
raw_text = ' '.join([x.lower() for x in clean])

# we get rid of the gap between every new poem
raw_text = raw_text.replace('\n \n \n \n', '')

# create mapping of unique chars to integers
chars = sorted(list(set(raw_text)))
char_to_int = {c: i for i, c in enumerate(chars)}
int_to_char = {i: c for i, c in enumerate(chars)}
# summarize the loaded data
n_chars = len(raw_text)
n_vocab = len(chars)

# preparing in data by chunking it into sequences of 40 chars
seq_length = 40
dataX = []
dataY = []

#we are using step size of 5
for i in range(0, n_chars - seq_length, 5):
	seq_in = raw_text[i:i + seq_length]
	seq_out = raw_text[i + seq_length]
	dataX.append([char_to_int[char] for char in seq_in])
	dataY.append(char_to_int[seq_out])

sentence_num = len(dataX)
#vectorize and one hot encoding
print("getting x and y")
X = np.zeros((sentence_num, seq_length, n_vocab), dtype=np.bool)
y = np.zeros((sentence_num, n_vocab), dtype=np.bool)
for i, sentence in enumerate(dataX):
    for j, char in enumerate(sentence):
        X[i, j, char] = 1
    y[i, dataY[i]] = 1


# change value of temp below for .25, .75. 1.5
temp = 0.75
model = Sequential()
model.add(LSTM(128, input_shape=(seq_length, n_vocab)))
model.add(Dense(n_vocab))
model.add(Lambda(lambda x: x / temp))
model.add(Activation('softmax'))
model.compile(loss='categorical_crossentropy', optimizer='adam')
model.fit(X, y, epochs=20)


#outputting results for LSTM 
pattern = raw_text[0:0 + seq_length]
output = ''
X = np.zeros((1, seq_length, n_vocab), dtype=np.bool)
for i, character in enumerate(pattern):
    X[0, i, char_to_int[character]] = 1

output = ""
newlinecount = 0
while newlinecount < 14:
    prediction = np.argmax(model.predict(X, verbose=0))
    if prediction == 0:
        newlinecount += 1
    output += int_to_char[prediction]
    activations = np.zeros((1, 1, n_vocab), dtype=np.bool)
    activations[0, 0, prediction] = 1
    X = np.concatenate((X[:, 1:, :], activations), axis=1)
                               
print(output)
