# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.


thoughts -- do we ignore the number headings??



"""

#!/usr/bin/env python
# processes shakespeare code into the format our code accepts

#in_file = open('data/shakespeare.txt', 'r')
#syllable_dic = open('data/syllable_dictionary.txt', 'r')

import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
#from hmmlearn import hmm
from sklearn.preprocessing import LabelEncoder
import json
import sys, time, pandas as pd
import nltk
from nltk.corpus import cmudict
import nltk.data
import string


d = cmudict.dict()
def nsyl(word):
    if word.lower() not in d.keys():
        return 11
    return max([len([y for y in x if y[-1].isdigit()]) for x in d[word.lower()]])

quatrainWords = []
coupletWords = []
voltaWords = []

quatrains = []
couplets = []
voltas = []

quatrain_n_syls_map = {}
volta_n_syls_map = {}
couplets_n_syls_map = {}

quatrain_word_map = {}
volta_word_map = {}
couplet_word_map = {}

q_rhymes = {}
v_rhymes = {}
c_rhymes = {}

f_shake = open('data/shakespeare.txt', 'r')
f_spence =  open('data/spenser.txt', 'r')

out_quatrains= 'out_quatrains.csv' 
out_voltas = 'out_voltas.csv' 
out_couplets = 'out_couplets.csv'
out_rhymes = 'out_rhymes.json'
out_q_rhymes = 'out_quatrain_rhymes.json'
out_v_rhymes = 'out_volta_rhymes.json'
out_c_rhymes = 'out_couplets_rhymes.json'
out_quatrain_w_to_i = 'out_q_w_map.json' 
out_volta_w_to_i = 'out_v_w_map.json' 
out_couplets_w_to_i = 'out_c_w_map.json'
out_quatrain_i_to_nsyl = 'out_quatrain_n_syls.json' 
out_volta_i_to_nsyl = 'out_volta_n_syls.json' 
out_couplets_i_to_nsyl= 'out_couplets_n_syls.json'   

shakeLines = f_shake.readlines()
spenceLines = f_spence.readlines()
curLineinPoem = 0
curQuatrain = []
curCouplet = []
curVolta = []
rhymeA = "";
rhymeB = "";
rhymeG = "";
for i, line in enumerate(shakeLines):
    line = line.strip()
    if line == '\n':
        continue
    if not line:  # line is blank
        continue
    words = [x.lower() for x in word_tokenize(line)]
    print (words)
    #prevElem = words[0]
    for i, elem in enumerate(words):
        if elem == "is" and prevElem == "'t": 
            words[i - 1] = "'tis"
            words.remove(elem)
            elem = words[i - 1]
        elif elem == "'s": 
            words[i - 1] += "'s"
            words.remove(elem)
            elem = words[i - 1]
        elif elem == "'d": 
            words[i - 1] += "'d"
            words.remove(elem)
            elem = words[i - 1]
        if elem in string.punctuation:
            words.remove(elem)
        prevElem = elem

    if words[0].isdigit():
        if (curQuatrain != []):
            quatrains.append(curQuatrain)
            voltas.append(curVolta)
            couplets.append(curCouplet)
        curLineinPoem = 0
        curQuatrain = []
        curCouplet = []
        curVolta = []
        continue
    lastWord = words[-1]
    if curLineinPoem < 4 or (curLineinPoem >= 8 and curLineinPoem < 12):
        if (curLineinPoem % 4 == 0):
            rhymeA = lastWord 
        if (curLineinPoem % 4 == 2):
            if nsyl(lastWord) != 11 and nsyl(rhymeA) != 11:
                if rhymeA in q_rhymes.keys():
                    if (lastWord  not in q_rhymes[rhymeA]):
                        q_rhymes[rhymeA].append(lastWord)
                else:
                    q_rhymes[rhymeA] = [lastWord]
                if lastWord in q_rhymes.keys():
                    if (rhymeA not in q_rhymes[lastWord]):
                        q_rhymes[lastWord].append(rhymeA) 
                else:
                    q_rhymes[lastWord] = [rhymeA]

        if (curLineinPoem % 4 == 1):
            rhymeB = lastWord
        if (curLineinPoem % 4 == 3):
            if nsyl(lastWord) != 11 and nsyl(rhymeB) != 11:
                if rhymeB in q_rhymes.keys():
                    if (lastWord not in q_rhymes[rhymeB]):
                        q_rhymes[rhymeB].append(lastWord)
                else:
                    q_rhymes[rhymeB] = [lastWord]
                if lastWord in q_rhymes.keys():
                    if (rhymeB not in q_rhymes[lastWord]):
                        q_rhymes[lastWord].append(rhymeB) 
                else:
                    q_rhymes[lastWord] = [rhymeB]

        quatrainWords += words
        curQuatrain += words
        if curLineinPoem % 4 != 3:
            curQuatrain += ['\n']
        elif curLineinPoem == 3:
            quatrains.append(curQuatrain)
            curQuatrain = []
    elif curLineinPoem >= 4 and curLineinPoem < 8:
        if (curLineinPoem % 4 == 0):
            rhymeA = lastWord 
        if (curLineinPoem % 4 == 2):
            if nsyl(lastWord) != 11 and nsyl(rhymeA) != 11:
                if rhymeA in v_rhymes.keys():
                    if (lastWord  not in v_rhymes[rhymeA]):
                        v_rhymes[rhymeA].append(lastWord)
                else:
                    v_rhymes[rhymeA] = [lastWord]
                if lastWord in v_rhymes.keys():
                    if (rhymeA not in v_rhymes[lastWord]):
                        v_rhymes[lastWord].append(rhymeA) 
                else:
                    v_rhymes[lastWord] = [rhymeA]

        if (curLineinPoem % 4 == 1):
            rhymeB = lastWord
        if (curLineinPoem % 4 == 3):
            if nsyl(lastWord) != 11 and nsyl(rhymeB) != 11:
                if rhymeB in v_rhymes.keys():
                    if (lastWord not in v_rhymes[rhymeB]):
                        v_rhymes[rhymeB].append(lastWord)
                else:
                    v_rhymes[rhymeB] = [lastWord]
                if lastWord in v_rhymes.keys():
                    if (rhymeB not in v_rhymes[lastWord]):
                        v_rhymes[lastWord].append(rhymeB) 
                else:
                    v_rhymes[lastWord] = [rhymeB]
        voltaWords += words
        curVolta += words
        if curLineinPoem != 7:
            curVolta.append('\n')
    else:
        if (curLineinPoem == 12):
            rhymeG = lastWord
        if (curLineinPoem == 13):
            if nsyl(lastWord) != 11 and nsyl(rhymeG) != 11:
                if rhymeG in c_rhymes.keys():
                    if (lastWord not in c_rhymes[rhymeG]):
                        c_rhymes[rhymeG].append(lastWord)
                else:
                    c_rhymes[rhymeG] = [lastWord]
                if lastWord in c_rhymes.keys():
                    if (rhymeG not in c_rhymes[lastWord]):
                        c_rhymes[lastWord].append(rhymeG) 
                else:
                    c_rhymes[lastWord] = [rhymeG]
        coupletWords += words
        curCouplet += words
        if curLineinPoem != 13:
            curCouplet.append('\n')
    curLineinPoem += 1
curLineinPoem = 0
curQuatrain = []
curCouplet = []
curVolta = []
for i, line in enumerate(spenceLines):
    line = line.strip()
    if not line:  # line is blank
        continue
    if line == '\n':
        continue
    words = [x.lower() for x in word_tokenize(line)]
    prevElem = words[0]
    for i, elem in enumerate(words):
        if elem == "is" and prevElem == "'t":
            words[i - 1] = "'tis"
            words.remove(elem)
            elem = words[i - 1]
        elif elem == "":
            words.remove(elem)
        elif elem == "'s": 
            words[i - 1] += "'s"
            words.remove(elem)
            elem = words[i - 1]
        elif elem == "'d": 
            words[i - 1] += "'d"
            words.remove(elem)
            elem = words[i - 1]
        if elem in string.punctuation:
            words.remove(elem)
        prevElem = elem


    if len(words) == 1:
        if (curQuatrain != []):
            quatrains.append(curQuatrain)
            voltas.append(curVolta)
            couplets.append(curCouplet)
        curLineinPoem = 0
        curQuatrain = []
        curCouplet = []
        curVolta = []
        continue
    lastWord = words[-1]
    if curLineinPoem < 4 or (curLineinPoem >= 8 and curLineinPoem < 12):
        if (curLineinPoem % 4 == 0):
            rhymeA = lastWord 
        if (curLineinPoem % 4 == 2):
            if nsyl(lastWord) != 11 and nsyl(rhymeA) != 11:
                if rhymeA in q_rhymes.keys():
                    if (lastWord  not in q_rhymes[rhymeA]):
                        q_rhymes[rhymeA].append(lastWord)
                else:
                    q_rhymes[rhymeA] = [lastWord]
                if lastWord in q_rhymes.keys():
                    if (rhymeA not in q_rhymes[lastWord]):
                        q_rhymes[lastWord].append(rhymeA) 
                else:
                    q_rhymes[lastWord] = [rhymeA]
        if (curLineinPoem % 4 == 1):
            rhymeB = lastWord
        if (curLineinPoem % 4 == 3):
            if nsyl(lastWord) != 11 and nsyl(rhymeB) != 11:
                if rhymeB in q_rhymes.keys():
                    if (lastWord not in q_rhymes[rhymeB]):
                        q_rhymes[rhymeB].append(lastWord)
                else:
                    q_rhymes[rhymeB] = [lastWord]
                if lastWord in q_rhymes.keys():
                    if (rhymeB not in q_rhymes[lastWord]):
                        q_rhymes[lastWord].append(rhymeB) 
                else:
                    q_rhymes[lastWord] = [rhymeB]
        quatrainWords += words
        curQuatrain += words
        if curLineinPoem % 4 != 3:
            curQuatrain.append('\n')
        elif curLineinPoem == 3:
            quatrains.append(curQuatrain)
            curQuatrain = []
    elif curLineinPoem >= 4 and curLineinPoem < 8:
        if (curLineinPoem % 4 == 0):
            rhymeA = lastWord 
        if (curLineinPoem % 4 == 2):
            if nsyl(lastWord) != 11 and nsyl(rhymeA) != 11:
                if rhymeA in v_rhymes.keys():
                    if (lastWord  not in v_rhymes[rhymeA]):
                        v_rhymes[rhymeA].append(lastWord)
                else:
                    v_rhymes[rhymeA] = [lastWord]
                if lastWord in v_rhymes.keys():
                    if (rhymeA not in v_rhymes[lastWord]):
                        v_rhymes[lastWord].append(rhymeA) 
                else:
                    v_rhymes[lastWord] = [rhymeA]

        if (curLineinPoem % 4 == 1):
            rhymeB = lastWord
        if (curLineinPoem % 4 == 3):
            if nsyl(lastWord) != 11 and nsyl(rhymeB) != 11:
                if rhymeB in v_rhymes.keys():
                    if (lastWord not in v_rhymes[rhymeB]):
                        v_rhymes[rhymeB].append(lastWord)
                else:
                    v_rhymes[rhymeB] = [lastWord]
                if lastWord in v_rhymes.keys():
                    if (rhymeB not in v_rhymes[lastWord]):
                        v_rhymes[lastWord].append(rhymeB) 
                else:
                    v_rhymes[lastWord] = [rhymeB]
        voltaWords += words
        curVolta += words
        if curLineinPoem != 7:
            curVolta.append('\n')
    else:
        if (curLineinPoem == 12):
            rhymeG = lastWord
        if (curLineinPoem == 13):
            if nsyl(lastWord) != 11 and nsyl(rhymeG) != 11:
                if rhymeG in c_rhymes.keys():
                    if (lastWord not in c_rhymes[rhymeG]):
                        c_rhymes[rhymeG].append(lastWord)
                else:
                    c_rhymes[rhymeG] = [lastWord]
                if lastWord in c_rhymes.keys():
                    if (rhymeG not in c_rhymes[lastWord]):
                        c_rhymes[lastWord].append(rhymeG) 
                else:
                    c_rhymes[lastWord] = [rhymeG]
        coupletWords += words
        curCouplet += words
        if curLineinPoem != 13:
            curCouplet.append('\n')
    curLineinPoem += 1
count_problems = 0
count_words = 0
for word in quatrainWords:
    if word not in quatrain_word_map.keys():
        quatrain_word_map[word] = count_words
        count_words += 1
        if word not in quatrain_n_syls_map.keys():
            if nsyl(word) == 11:
                count_problems += 1
            quatrain_n_syls_map[count_words - 1] = nsyl(word)
count_words = 0
for word in voltaWords:
    if word not in volta_word_map.keys():
        volta_word_map[word] = count_words
        count_words += 1
        if word not in volta_n_syls_map.keys():
            if nsyl(word) == 11:
                count_problems += 1
            volta_n_syls_map[count_words - 1] = nsyl(word)
count_words = 0
for word in coupletWords:
    if word not in couplet_word_map.keys():
        couplet_word_map[word] = count_words
        count_words += 1
        if word not in couplets_n_syls_map.keys():
            if nsyl(word) == 11:
                count_problems += 1
            couplets_n_syls_map[count_words - 1] = nsyl(word)
with open(out_quatrains, 'w') as f: 
    for i in range(len(quatrains)):
        quatrains[i].reverse()
        line = ''
        for elem in quatrains[i]:
            if (elem == '\n'):
                line += elem
            else:
                line += elem + ','
        line += '\n'
        line = line.replace(',\n','\n')
        f.write(line)
print(out_quatrains)

with open(out_voltas, 'w') as f: 
    for i in range(len(voltas)):
        voltas[i].reverse()
        line = ''
        for elem in voltas[i]:
            if (elem == '\n'):
                line += elem
            else:
                line += elem + ','
        line += '\n'
        line = line.replace(',\n','\n')
        f.write(line)
print(out_voltas)
with open(out_couplets, 'w') as f: 
    for i in range(len(couplets)):
        couplets[i].reverse()
        line = ''
        for elem in couplets[i]:
            if (elem == '\n'):
                line += elem
            else:
                line += elem + ','
        line += '\n'
        line = line.replace(',\n','\n')
        f.write(line)
print(out_couplets)
with open(out_quatrain_w_to_i, 'w') as f: 
    json.dump(quatrain_word_map, f)
print(out_quatrain_w_to_i)
with open(out_volta_w_to_i, 'w') as f: 
    json.dump(volta_word_map, f)
print(out_volta_w_to_i)
with open(out_couplets_w_to_i, 'w') as f: 
    json.dump(couplet_word_map, f)
print(out_couplets_w_to_i)
with open(out_quatrain_i_to_nsyl, 'w') as f: 
    json.dump(quatrain_n_syls_map, f)
print(out_quatrain_i_to_nsyl)
with open(out_volta_i_to_nsyl, 'w') as f: 
    json.dump(volta_n_syls_map, f)
print(out_volta_i_to_nsyl)
with open(out_couplets_i_to_nsyl, 'w') as f: 
    json.dump(couplets_n_syls_map, f)
print(out_couplets_i_to_nsyl)
with open(out_q_rhymes, 'w') as f: 
    json.dump(q_rhymes, f)
print(out_q_rhymes)
with open(out_v_rhymes, 'w') as f: 
    json.dump(v_rhymes, f)
print(out_v_rhymes)
with open(out_c_rhymes, 'w') as f: 
    json.dump(c_rhymes, f)
print(out_c_rhymes)